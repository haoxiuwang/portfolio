export default function Note() {
  return(<p><strong>Note</strong>: <em>These codes is just for myself to study programming.</em></p>)
}
